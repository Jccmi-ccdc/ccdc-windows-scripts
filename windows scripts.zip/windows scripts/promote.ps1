function Promote-UserToAdmin {
    param (
        [string]$username
    )

    $userExists = Test-LocalUser -Name $username
    if ($userExists) {
        Add-LocalGroupMember -Group "Administrators" -Member $username
        Write-Host "The user '$username' has been promoted to an administrator."
    } else {
        Write-Host "User '$username' does not exist."
    }
}

$username = Read-Host "Enter username to promote to admin:"

Promote-UserToAdmin -username $username
