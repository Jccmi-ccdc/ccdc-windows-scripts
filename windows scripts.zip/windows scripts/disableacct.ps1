function Disable-UserAccount {
    param (
        [string]$username
    )

    $userExists = Test-LocalUser -Name $username
    if ($userExists) {
        Disable-LocalUser -Name $username
        Write-Host "The account '$username' has been disabled."
    } else {
        Write-Host "User '$username' does not exist."
    }
}

$username = Read-Host "Enter username to disable:"

Disable-UserAccount -username $username
