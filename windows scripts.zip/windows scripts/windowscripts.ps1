function run_program($filename) {
    Start-Process "powershell" $filename
}

function display_menu_windows {
    Write-Host "1. Change admin password"
    Write-Host "2. Create new user (make a duck)"
    Write-Host "3. Promote user to admin"
    Write-Host "4. Disable SAM accounts"
    Write-Host "5. Update"
    Write-Host "6. Open Windows Firewall"
    Write-Host "7. Run security lockdown"
    Write-Host "8. Exit"
}

function get_user_choice {
    while ($true) {
        try {
            $choice = Read-Host "Enter your choice (1-8):"
            $choice = [int]$choice
            if ($choice -ge 1 -and $choice -le 8) {
                return $choice
            } else {
                Write-Host "Enter a number between 1 and 8."
            }
        } catch {
            Write-Host "Invalid choice. Please enter a number."
        }
    }
}

$os_type = Read-Host "Enter 'w' for Windows:"

if ($os_type -eq 'w') {
    $file_extension = '.ps1'
    display_menu_windows

    while ($true) {
        $choice = get_user_choice

        if ($choice -eq 8) {
            Write-Host "Exiting program."
            break
        }

        $filename = ""

        switch ($choice) {
            1 { $filename = "wpasswd.ps1" }
            2 { $filename = "wRubberDuck.ps1" }
            3 { $filename = "promote.ps1" }
            4 { $filename = "disableacct.ps1" }
            5 { $filename = "wupdate.ps1" }
            6 { $filename = "wfirewall.ps1" }
            7 { $filename = "security.ps1" }
        }

        if ($filename -ne "") {
            run_program($filename)
        } else {
            Write-Host "Invalid selection. File does not exist."
        }
    }
} else {
    Write-Host "Invalid input. This script is for Windows only."
}

