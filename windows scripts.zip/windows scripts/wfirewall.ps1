function Enable-WindowsFirewall {
    Set-NetFirewallProfile -Profile Domain,Public,Private -Enabled True
    Set-NetFirewallProfile -Profile Domain,Public,Private -DefaultInboundAction Block
    Set-NetFirewallProfile -Profile Domain,Public,Private -DefaultOutboundAction Allow
}

Enable-WindowsFirewall
Write-Host "Windows Firewall has been enabled with basic settings."
