function Add-User {
    param (
        [string]$username,
        [string]$password
    )

    $userExists = Test-LocalUser -Name $username
    if (-not $userExists) {
        New-LocalUser -Name $username -Password (ConvertTo-SecureString -String $password -AsPlainText -Force) -AccountNeverExpires $true
        Add-LocalGroupMember -Group "Administrators" -Member $username
        Write-Host "The user '$username' has been added and promoted to an administrator."
    } else {
        Write-Host "User '$username' already exists."
    }
}

$username = Read-Host "Enter the username:"
$password = Read-Host -AsSecureString "Enter the password:" 

Add-User -username $username -password $password
