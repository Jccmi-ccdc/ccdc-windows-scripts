function Change-UserPassword {
    param (
        [string]$username,
        [string]$newPassword
    )

    $securePassword = ConvertTo-SecureString -String $newPassword -AsPlainText -Force
    Set-LocalUser -Name $username -Password $securePassword
}

$username = Read-Host "Enter your username:"
$currentPassword = Read-Host -AsSecureString "Enter your current password:"
$newPassword = Read-Host -AsSecureString "Enter your new password:"

$plainNewPassword = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto([System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($newPassword))

Change-UserPassword -username $username -newPassword $plainNewPassword

Write-Host "Password changed successfully."
