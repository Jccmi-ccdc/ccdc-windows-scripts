# Initiate a Windows Update check
Install-WindowsUpdate -MicrosoftUpdate -AcceptAll -AutoReboot

# Display a message
Write-Host "System updates are being checked. Please wait... system will restart if needbe"